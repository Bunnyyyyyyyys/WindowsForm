﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Voencomat
{
    public partial class SupportForm : Form
    {
        private Dictionary<string, Dictionary<string, string>> categories;

        public SupportForm()
        {
            InitializeComponent();
            InitializeQuestionsAndAnswers();
            LoadCategories();
            cmbCategories.SelectedIndexChanged += CmbCategories_SelectedIndexChanged;
            cmbQuestions.SelectedIndexChanged += CmbQuestions_SelectedIndexChanged;
        }

        private void InitializeQuestionsAndAnswers()
        {
            categories = new Dictionary<string, Dictionary<string, string>>
            {
                { "Призыв", new Dictionary<string, string>
                    {
                        { "Какой возраст для призыва?", "Призывной возраст в России составляет от 18 до 27 лет." },
                        { "Что делать, если пришла повестка?", "Необходимо явиться в указанный срок в военкомат." },
                        { "Как проверить свою призывную категорию?", "Для этого нужно обратиться в военкомат или проверить на официальном сайте." }
                    }
                },
                { "Военный билет", new Dictionary<string, string>
                    {
                        { "Что такое военный билет?", "Военный билет — это документ, подтверждающий статус гражданина в отношении военной службы." },
                        { "Как получить военный билет после службы?", "Военный билет выдают в части после окончания службы." },
                        { "Как получить справку о наличии военного билета?", "Обратитесь в военкомат с документами, удостоверяющими личность." }
                    }
                },
                { "Медицинская комиссия", new Dictionary<string, string>
                    {
                        { "Как подготовиться к медицинской комиссии?", "Рекомендуется пройти профилактические обследования и собрать все медицинские справки." },
                        { "Как узнать свою категорию годности к службе?", "Для получения информации о вашей категории годности вам необходимо обратиться в военкомат по месту жительства." },
                        { "Что делать, если у меня есть проблемы со здоровьем?", "Соберите все документы и справки от врачей для подтверждения вашей категории годности." }
                    }
                },
                { "Отсрочки и освобождения", new Dictionary<string, string>
                    {
                        { "Как получить отсрочку от призыва?", "Отсрочку можно получить по различным причинам, таким как учеба или наличие детей." },
                        { "Можно ли получить освобождение от службы по семейным обстоятельствам?", "Да, необходимо предоставить соответствующие документы." }
                    }
                },
                { "Обжалование решений", new Dictionary<string, string>
                    {
                        { "Что делать, если я не согласен с решением военкомата?", "Если вы не согласны с решением, вы можете подать апелляцию." },
                        { "Как обжаловать решение о призыве?", "Необходимо подать заявление в суд или вышестоящую инстанцию." }
                    }
                },
                { "Общие вопросы", new Dictionary<string, string>
                    {
                        { "Можно ли получить информацию о призыве через интернет?", "Да, многие военкоматы предоставляют возможность получить информацию через официальные сайты." },
                        { "Как узнать, когда начинается призыв?", "Призыв проходит два раза в год: весной и осенью." },
                        { "Что делать, если я не получил повестку?", "Если вы не получили повестку, рекомендуется обратиться в военкомат." },
                        { "Что такое контрактная служба?", "Контрактная служба — это форма службы с подписанием контракта на определённый срок." },
                       { "Каковы права призывника?", "Призывник имеет право на получение информации о своих правах." },
                        { "Как узнать, где находится мой военкомат?", "Вы можете найти информацию на официальном сайте Министерства обороны." },
                        { "Каковы последствия уклонения от призыва?", "Уклонение может привести к административной или уголовной ответственности." },
                        { "В какие войска меня могут взять?", "Зависит от Вашей категории здоровья." }
                    }
                }
            };
        }

        private void LoadCategories()
        {
            foreach (var category in categories.Keys)
            {
                cmbCategories.Items.Add(category);
            }
        }

        private void CmbCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbQuestions.Items.Clear(); // Очистить предыдущие вопросы
            if (cmbCategories.SelectedItem != null)
            {
                string selectedCategory = cmbCategories.SelectedItem.ToString();
                foreach (var question in categories[selectedCategory].Keys)
                {
                    cmbQuestions.Items.Add(question);
                }
            }
        }

        private void CmbQuestions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbQuestions.SelectedItem != null && cmbCategories.SelectedItem != null)
            {
                string selectedCategory = cmbCategories.SelectedItem.ToString();
                string selectedQuestion = cmbQuestions.SelectedItem.ToString();
                txtAnswer.Text = categories[selectedCategory][selectedQuestion];
            }
            else
            {
                txtAnswer.Clear(); // Очистить текстовое поле, если ничего не выбрано
            }
        }
    }
}


