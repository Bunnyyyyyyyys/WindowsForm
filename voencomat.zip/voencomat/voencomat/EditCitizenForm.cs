﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static voencomat.Form1;

namespace voencomat
{
    public partial class EditCitizenForm : Form
    {
        private Citizen citizen;

        public EditCitizenForm(Citizen citizenToEdit)
        {
            InitializeComponent();
            citizen = citizenToEdit;

            // Заполнение полей данными гражданина
            txtEditFullName.Text = citizen.FullName;
            dtpEditBirthDate.Value = citizen.BirthDate;
            cmbEditStatus.SelectedItem = citizen.Status;
        }

        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            // Обновляем данные гражданина
            citizen.FullName = txtEditFullName.Text;
            citizen.BirthDate = dtpEditBirthDate.Value;
            citizen.Status = cmbEditStatus.SelectedItem.ToString();

            DialogResult = DialogResult.OK; // Указываем, что изменения сохранены
            Close(); // Закрываем форму
        }
    }
}
