﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Voencomat;

namespace voencomat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public class Citizen
        {
            public string FullName { get; set; }
            public DateTime BirthDate { get; set; }
            public string Status { get; set; } 
        }

        private List<Citizen> citizens = new List<Citizen>();
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text) || cmbStatus.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            Citizen citizen = new Citizen
            {
                FullName = txtFullName.Text,
                BirthDate = dtpBirthDate.Value,
                Status = cmbStatus.SelectedItem.ToString()
            };

            citizens.Add(citizen);
            UpdateDataGridView();
            ClearInputs();

        }

        private void UpdateDataGridView()
        {
            dataGridView.DataSource = null;
            dataGridView.DataSource = citizens; // обновление источника данных
        }

        private void ClearInputs()
        {
            txtFullName.Clear();
            dtpBirthDate.Value = DateTime.Now;
            cmbStatus.SelectedIndex = -1;
        }

        private void SetupDataGridView()
        {
            // Очистить существующие столбцы
            dataGridView.Columns.Clear();

            // Создать столбец для ФИО
            DataGridViewTextBoxColumn fullNameColumn = new DataGridViewTextBoxColumn();
            fullNameColumn.HeaderText = "ФИО";
            fullNameColumn.DataPropertyName = "FullName"; // Связываем с моделью
            dataGridView.Columns.Add(fullNameColumn);

            // Создать столбец для даты рождения
            DataGridViewTextBoxColumn birthDateColumn = new DataGridViewTextBoxColumn();
            birthDateColumn.HeaderText = "Дата рождения";
            birthDateColumn.DataPropertyName = "BirthDate";
            dataGridView.Columns.Add(birthDateColumn);

            // Создать столбец для статуса
            DataGridViewTextBoxColumn statusColumn = new DataGridViewTextBoxColumn();
            statusColumn.HeaderText = "Статус";
            statusColumn.DataPropertyName = "Status";
            dataGridView.Columns.Add(statusColumn);

            // Разрешаем редактирование
            fullNameColumn.ReadOnly = false;
            birthDateColumn.ReadOnly = false;
            statusColumn.ReadOnly = false;
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
 

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                // Получаем выбранную строку
                var selectedRow = dataGridView.SelectedRows[0];

                // Удаляем запись из источника данных
                var citizenToDelete = citizens[selectedRow.Index];
                citizens.Remove(citizenToDelete);

                // Обновляем DataGridView
                UpdateDataGridView();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
            }
        }

        private void btnEditCitizen_Click(object sender, EventArgs e)
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                var selectedCitizen = citizens[dataGridView.SelectedRows[0].Index];
                EditCitizenForm editForm = new EditCitizenForm(selectedCitizen);

                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    UpdateDataGridView(); // Обновляем DataGridView после редактирования
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите гражданина для редактирования.");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSupport_Click(object sender, EventArgs e)
        {
            SupportForm supportForm = new SupportForm();
            supportForm.ShowDialog();
        }
    }
}
