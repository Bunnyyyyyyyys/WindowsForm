﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace RecipeApp
{
    public partial class MainForm : Form
    {
        private Dictionary<string, List<Recipe>> recipesByCategory;

        public MainForm()
        {
            InitializeComponent();
            InitializeData();
            LoadCategories();
        }

        private void InitializeData()
        {
            // Инициализация данных о рецептах
            recipesByCategory = new Dictionary<string, List<Recipe>>
            {
                { "Завтраки", new List<Recipe>
                    {
                        new Recipe("Омлет", "Ингредиенты: яйца, молоко, соль. Способ приготовления: взбить яйца с молоком и жарить на сковороде."),
                        new Recipe("Каша", "Ингредиенты: овсяные хлопья, вода, соль. Способ приготовления: варить овсяные хлопья в воде до готовности.")
                    }
                },
                { "Ужины", new List<Recipe>
                    {
                        new Recipe("Паста", "Ингредиенты: паста, томатный соус, специи. Способ приготовления: отварить пасту и смешать с соусом."),
                        new Recipe("Салат", "Ингредиенты: овощи, оливковое масло, соль. Способ приготовления: нарезать овощи и заправить маслом.")
                    }
                },
                { "Супы", new List<Recipe>
                    {
                        new Recipe("Суп-пюре из тыквы", "Вкусный и полезный суп с тыквой."),
                        new Recipe("Грибной суп", "Нежный суп с лесными грибами.")
                    }
                },
                { "Основные блюда", new List<Recipe>
                    {
                new Recipe("Курица с овощами", "Запеченная курица с сезонными овощами."),
                new Recipe("Паста Карбонара", "Итальянская паста с беконом и сыром.")
                    }
                },
                { "Десерты", new List<Recipe>
                    {
                        new Recipe("Шоколадный торт", "Нежный шоколадный торт с кремом."),
                        new Recipe("Фруктовый салат", "Свежий салат из seasonal фруктов.")
                    }
                },
                { "Закуски", new List<Recipe>
                    {
                        new Recipe("Брускетта с помидорами", "Хрустящий хлеб с помидорами и базиликом."),
                        new Recipe("Капрезе", "Салат из моцареллы, помидоров и базилика.")
                    }
                }
            };
        }

        private void LoadCategories()
        {
            // Загрузка категорий в ComboBox
            comboBoxCategories.Items.AddRange(recipesByCategory.Keys.ToArray());
        }

        private void listBoxRecipes_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Отображение деталей рецепта при выборе из списка
            if (listBoxRecipes.SelectedItem != null)
            {
                string selectedRecipeName = listBoxRecipes.SelectedItem.ToString();
                var selectedRecipe = recipesByCategory[comboBoxCategories.SelectedItem.ToString()]
                                    .FirstOrDefault(r => r.Name == selectedRecipeName);

                if (selectedRecipe != null)
                {
                    textBoxDetails.Text = selectedRecipe.Details;
                }
            }
        }

        private void comboBoxCategories_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Обновление списка рецептов при выборе категории
            string selectedCategory = comboBoxCategories.SelectedItem.ToString();
            listBoxRecipes.Items.Clear();
            listBoxRecipes.Items.AddRange(recipesByCategory[selectedCategory].Select(r => r.Name).ToArray());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Kulinaria kulinariaForm = new Kulinaria();
            kulinariaForm.Show();
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public string Details { get; set; }

        public Recipe(string name, string details)
        {
            Name = name;
            Details = details;
        }
    }
}

