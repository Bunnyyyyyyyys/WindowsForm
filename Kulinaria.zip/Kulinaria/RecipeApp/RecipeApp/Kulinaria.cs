﻿using System;
using System.Windows.Forms;

namespace RecipeApp
{
    public partial class Kulinaria : Form
    {
        private int questionStep = 0;
        public Kulinaria()
        {
            InitializeComponent();
            ShowQuestion1();
        }

        private void ShowQuestion1()
        {
            questionLabel.Text = "Предпочитаете ли вы готовить самостоятельно?";
            buttonYes.Text = "Да";
            buttonNo.Text = "Нет";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion2()
        {
            questionLabel.Text = "Какой тип кухни вам нравится больше?";
            buttonYes.Text = "Итальянская";
            buttonNo.Text = "Азиатская";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion3()
        {
            questionLabel.Text = "Любите ли вы пасту?";
            buttonYes.Text = "Да";
            buttonNo.Text = "Нет";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion4()
        {
            questionLabel.Text = "Нравится ли вам острая пища?";
            buttonYes.Text = "Да";
            buttonNo.Text = "Нет";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion5()
        {
            questionLabel.Text = "Вы пробовали тайскую кухню?";
            buttonYes.Text = "Да";
            buttonNo.Text = "Нет";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion6()
        {
            questionLabel.Text = "Какой ваш любимый способ приготовления пищи?";
            buttonYes.Text = "Запекание";
            buttonNo.Text = "Жарка";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion7()
        {
            questionLabel.Text = "Предпочитаете ли вы запекать мясо?";
            buttonYes.Text = "Да";
            buttonNo.Text = "Нет";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion8()
        {
            questionLabel.Text = "Любите ли вы жареный картофель?";
            buttonYes.Text = "Да";
            buttonNo.Text = "Нет";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion9()
        {
            questionLabel.Text = "На какой праздник вы обычно готовите?";
            buttonYes.Text = "Новый год";
            buttonNo.Text = "День рождения";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void ShowQuestion10()
        {
            questionLabel.Text = "Вы любите макароны?";
            buttonYes.Text = "Да";
            buttonNo.Text = "Нет";
            buttonYes.Visible = true;
            buttonNo.Visible = true;
            resultLabel.Text = ""; // Очищаем результат
        }

        private void buttonYes_Click(object sender, EventArgs e)
        {
            if (questionLabel.Text == "Предпочитаете ли вы готовить самостоятельно?")
                ShowQuestion2();
            else if (questionLabel.Text == "Какой тип кухни вам нравится больше?")
                if (buttonYes.Text == "Итальянская")
                    ShowQuestion3();
                else
                    ShowQuestion4();
            else if (questionLabel.Text == "Любите ли вы пасту?")
                resultLabel.Text = "Отлично! Феттучини Alfredo - это вкусно!";
            else if (questionLabel.Text == "Нравится ли вам острая пища?")
                ShowQuestion5();
            else if (questionLabel.Text == "Вы пробовали тайскую кухню?")
                resultLabel.Text = "Тайская кухня - это великолепно!";
            else if (questionLabel.Text == "Какой ваш любимый способ приготовления пищи?")
                if (buttonYes.Text == "Запекание")
                    ShowQuestion7();
                else
                    ShowQuestion8();
            else if (questionLabel.Text == "Предпочитаете ли вы запекать мясо?")
                resultLabel.Text = "Запечённое мясо - это деликатес!";
            else if (questionLabel.Text == "Любите ли вы жареный картофель?")
                ShowQuestion9();
            else if (questionLabel.Text == "На какой праздник вы обычно готовите?")
                if (buttonYes.Text == "Новый год")
                    resultLabel.Text = "В Новый год без картошки - никуда!";
                else
                    resultLabel.Text = "Картошечка - это обязательный элемент!";
            else if (questionLabel.Text == "Вы любите макароны?")
                resultLabel.Text = "Здорово! Попробуйте макароны с сырным соусом - это очень вкусно!";
        }

        private void buttonNo_Click(object sender, EventArgs e)
        {
            if (questionLabel.Text == "Предпочитаете ли вы готовить самостоятельно?")
                resultLabel.Text = "Не хотите готовить? Попробуйте заказать еду.";
            else if (questionLabel.Text == "Какой тип кухни вам нравится больше?")
                if (buttonNo.Text == "Азиатская")
                    ShowQuestion4();
                else
                    resultLabel.Text = "Попробуйте сделать пиццу!";
            else if (questionLabel.Text == "Нравится ли вам острая пища?")
                resultLabel.Text = "Попробуйте японские роллы без острого.";
            else if (questionLabel.Text == "Вы пробовали тайскую кухню?")
                ShowQuestion6();
            else if (questionLabel.Text == "Какой ваш любимый способ приготовления пищи?")
                ShowQuestion8();
            else if (questionLabel.Text == "Любите ли вы жареный картофель?")
                ShowQuestion10();
            else if (questionLabel.Text == "Вы любите макароны?")
                resultLabel.Text = "Попробуйте булгур, он вам должен понравиться!";
            else if (questionLabel.Text == "Любите ли вы пасту?")
                resultLabel.Text = "Попробуйте сделать пиццу!";
            else if (questionLabel.Text == "Предпочитаете ли вы запекать мясо?")
                resultLabel.Text = "Попробуйте запечь овощи с приправами!";
        }
    }
}
