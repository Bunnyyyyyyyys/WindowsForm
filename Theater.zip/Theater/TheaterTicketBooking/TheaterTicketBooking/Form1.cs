﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using TheaterTicketBooking;
using TheaterSelectionApp;

namespace TicketBookingApp
{
    public partial class MainForm : Form
    {
        private readonly Dictionary<string, ShowDetails> _shows = new Dictionary<string, ShowDetails>
        {
            { "Ромео и Джульетта", new ShowDetails { 
                SeatTypes = new Dictionary<string, decimal> { { "Стандарт", 500 }, { "Балкон", 300 }, { "VIP", 1000 } },
                ShowTime = "19:00",
                Duration = "2 часа",
                Genre = "Трагедия"
            }},
            { "Гамлет", new ShowDetails { 
                SeatTypes = new Dictionary<string, decimal> { { "Стандарт", 700 }, { "Балкон", 500 }, { "VIP", 1000 } },
                ShowTime = "20:00",
                Duration = "2.5 часа",
                Genre = "Трагедия"
            }},
            { "Мастер и Маргарита", new ShowDetails { 
                SeatTypes = new Dictionary<string, decimal> { { "Стандарт", 600 }, { "Балкон", 400 }, { "VIP", 1000 } },
                ShowTime = "18:30",
                Duration = "2 часа",
                Genre = "Романтическая комедия"
            }}
        };

        private List<string> _purchasedTickets = new List<string>();

        public MainForm()
        {
            InitializeComponent();
            InitializeShowComboBox();
            UpdateTicketPrice(); // Инициализация цены при загрузке формы
        }

        private void InitializeShowComboBox()
        {
            comboBoxShows.Items.Clear();
            foreach (var show in _shows.Keys)
            {
                comboBoxShows.Items.Add(show);
            }
            comboBoxShows.SelectedIndex = 0; // Устанавливаем первый элемент по умолчанию

            UpdateSeatTypeComboBox();
            UpdateShowDetails(); // Обновляем детали спектакля при загрузке
        }

        private void comboBoxShows_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateSeatTypeComboBox();
            UpdateShowDetails(); // Обновляем детали спектакля при смене спектакля
            UpdateTicketPrice(); // Обновляем цену при смене спектакля
        }

        private void comboBoxSeatType_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            UpdateTicketPrice(); // Обновляем цену при смене типа места
        }

        private void UpdateSeatTypeComboBox()
        {
            comboBoxSeatType.Items.Clear();
            string selectedShow = comboBoxShows.SelectedItem.ToString();

            foreach (var seatType in _shows[selectedShow].SeatTypes.Keys)
            {
                comboBoxSeatType.Items.Add(seatType);
            }

            comboBoxSeatType.SelectedIndex = 0; // Устанавливаем первый элемент по умолчанию
        }

        private void UpdateShowDetails()
        {
            string selectedShow = comboBoxShows.SelectedItem.ToString();
            var showDetails = _shows[selectedShow];

            labelShowTime.Text = $"Время: {showDetails.ShowTime}";
            labelDuration.Text = $"Продолжительность: {showDetails.Duration}";
            labelGenre.Text = $"Жанр: {showDetails.Genre}";
        }

        private void UpdateTicketPrice()
        {
            string selectedShow = comboBoxShows.SelectedItem.ToString();
            string selectedSeatType = comboBoxSeatType.SelectedItem.ToString();
            decimal ticketPrice = _shows[selectedShow].SeatTypes[selectedSeatType];
            labelTicketPrice.Text = $"Цена: {ticketPrice} руб."; // Обновляем текст метки с ценой
        }

        private void buttonPurchase_Click(object sender, EventArgs e)
        {
            string selectedShow = comboBoxShows.SelectedItem.ToString();
            string selectedSeatType = comboBoxSeatType.SelectedItem.ToString();
            int ticketCount = (int)numericUpDownTickets.Value;

            if (ticketCount > 0)
            {
                decimal ticketPrice = _shows[selectedShow].SeatTypes[selectedSeatType];
                decimal totalPrice = ticketPrice * ticketCount;
                string ticketInfo = $"Куплено: {ticketCount} билет(ов) на '{selectedShow}' ({selectedSeatType}) за {totalPrice} рублей.";

                _purchasedTickets.Add(ticketInfo); // Сохраняем информацию о купленном билете
                MessageBox.Show(ticketInfo, "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Можно очистить количество билетов после покупки
                numericUpDownTickets.Value = 1;

            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите количество билетов.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonViewPurchases_Click(object sender, EventArgs e)
        {
            if (_purchasedTickets.Count > 0)
            {
                PurchasedTicketsForm purchasedTicketsForm = new PurchasedTicketsForm(_purchasedTickets.ToArray());
                purchasedTicketsForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("У вас нет купленных билетов.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void labelTickets_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Создаем экземпляр Name
            Name name = new Name();
            // Открываем новую форму
            name.Show();
        }
    }

    public class ShowDetails
    {
        public Dictionary<string, decimal> SeatTypes { get; set; }
        public string ShowTime { get; set; }
        public string Duration { get; set; }
        public string Genre { get; set; }
    }
}
