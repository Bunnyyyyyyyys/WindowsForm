﻿using System;
using System.Windows.Forms;
using TicketBookingApp;

namespace TheaterSelectionApp
{
    public partial class Name : Form
    {
        public Name()
        {
            InitializeComponent();
            InitializeMainMenu();
        }

        private void InitializeMainMenu()
        {
            // Настройка начального интерфейса
            labelQuestion.Text = "Какой тип театрального мероприятия вас интересует?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Спектакль");
            comboBoxOptions.Items.Add("Концерт");
            buttonConfirm.Click += new EventHandler(OnMainOptionSelected);
        }

        private void OnMainOptionSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedOption = comboBoxOptions.SelectedItem.ToString();

            if (selectedOption == "Спектакль")
            {
                ShowGenreSelection();
            }
            else
            {
                labelRecommendation.Text = "У нас только театральные постановки.";
            }
        }
        private void buttonConfirm_Click(object sender, EventArgs e)
        {

        }
        private void ShowGenreSelection()
        {
            labelQuestion.Text = "Какой жанр спектакля вас интересует?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Драма");
            comboBoxOptions.Items.Add("Комедия");
            buttonConfirm.Click -= OnMainOptionSelected;
            buttonConfirm.Click += new EventHandler(OnGenreSelected);
        }

        private void OnGenreSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите жанр.");
                return;
            }

            string selectedGenre = comboBoxOptions.SelectedItem.ToString();

            if (selectedGenre == "Драма")
            {
                ShowDramaSelection();
            }
            else
            {
                ShowComedySelection();
            }
        }

        private void ShowDramaSelection()
        {
            labelQuestion.Text = "Вы предпочитаете классические или современные пьесы?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Классические");
            comboBoxOptions.Items.Add("Современные");
            buttonConfirm.Click -= OnGenreSelected;
            buttonConfirm.Click += new EventHandler(OnDramaSelected);
        }

        private void OnDramaSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedDrama = comboBoxOptions.SelectedItem.ToString();

            if (selectedDrama == "Классические")
            {
                labelRecommendation.Text = "Посмотрите 'Гамлет'.";
            }
            else
            {
                ShowModernDramaSelection();
            }
        }

        private void ShowModernDramaSelection()
        {
            labelQuestion.Text = "Вы ищете пьесу с известными актерами или начинающими?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Известные актеры");
            comboBoxOptions.Items.Add("Начинающие актеры");
            buttonConfirm.Click -= OnDramaSelected;
            buttonConfirm.Click += new EventHandler(OnModernDramaSelected);
        }

        private void OnModernDramaSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedModernDrama = comboBoxOptions.SelectedItem.ToString();

            if (selectedModernDrama == "Известные актеры")
            {
                labelRecommendation.Text = "Посмотрите пьесу 'Русский крест'.";
            }
            else
            {
                labelRecommendation.Text = "Вам стоит сходить посмотреть спектакль в учебные учреждения для актеров.";
            }
        }

        private void ShowComedySelection()
        {
            labelQuestion.Text = "Какой вид комедии вас интересует?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Ситком");
            comboBoxOptions.Items.Add("Сатирическая комедия");
            buttonConfirm.Click -= OnGenreSelected;
            buttonConfirm.Click += new EventHandler(OnComedySelected);
        }

        private void OnComedySelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите жанр комедии.");
                return;
            }

            string selectedComedy = comboBoxOptions.SelectedItem.ToString();

            if (selectedComedy == "Ситком")
            {
                ShowSitcomSelection();
            }
            else
            {
                ShowSatiricalComedySelection();
            }
        }

        private void ShowSitcomSelection()
        {
            labelQuestion.Text = "Хотите ли вы, чтобы это была мюзикл-комедия?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Да");
            comboBoxOptions.Items.Add("Нет");
            buttonConfirm.Click -= OnComedySelected;
            buttonConfirm.Click += new EventHandler(OnSitcomSelected);
        }

        private void OnSitcomSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedSitcom = comboBoxOptions.SelectedItem.ToString();

            if (selectedSitcom == "Да")
            {
                ShowMusicalComedySelection();
            }
            else
            {
                ShowFormatSelection(); // Переход к выбору формата
            }
        }

        private void ShowFormatSelection()
        {
            labelQuestion.Text = "Какой формат вам ближе?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Обычный спектакль");
            comboBoxOptions.Items.Add("Прямой эфир (стрим)");

            buttonConfirm.Click -= OnSitcomSelected;
            buttonConfirm.Click += new EventHandler(OnFormatSelected);
        }

        private void OnFormatSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedFormat = comboBoxOptions.SelectedItem.ToString();

            if (selectedFormat == "Обычный спектакль")
            {
                labelRecommendation.Text = "Приходите к нам в театр на новые спектакли!";
            }
            else if (selectedFormat == "Прямой эфир (стрим)")
            {
                labelRecommendation.Text = "Наши спектакли можно посмотреть даже дома в эфире!";
            }
        }

        private void ShowMusicalComedySelection()
        {
            labelQuestion.Text = "Вы заинтересованы в мюзиклах с элементами танца?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Да");
            comboBoxOptions.Items.Add("Нет");
            buttonConfirm.Click -= OnSitcomSelected;
            buttonConfirm.Click += new EventHandler(OnMusicalComedySelected);
        }

        private void OnMusicalComedySelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedMusical = comboBoxOptions.SelectedItem.ToString();

            if (selectedMusical == "Да")
            {
                ShowDanceStyleSelection();
            }
            else
            {
                labelRecommendation.Text = "Если вам не нравятся танцы, то ходите на мьюзиклы без них.";
            }
        }

        private void ShowDanceStyleSelection()
        {
            labelQuestion.Text = "Какой стиль танца вам интересен?";
            comboBoxOptions.Items.Clear();

            comboBoxOptions.Items.Add("Балет");
            comboBoxOptions.Items.Add("Современный танец");
            buttonConfirm.Click -= OnMusicalComedySelected;
            buttonConfirm.Click += new EventHandler(OnDanceStyleSelected);
        }

        private void OnDanceStyleSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите стиль танца.");
                return;
            }

            string selectedDanceStyle = comboBoxOptions.SelectedItem.ToString();

            if (selectedDanceStyle == "Балет")
            {
                labelRecommendation.Text = "В нашем театре присутствует балет, приходите к нам!";
            }
            else
            {
                labelRecommendation.Text = "У нас есть спектакли с современными танцами, приходите!";
            }
        }

        private void ShowSatiricalComedySelection()
        {
            labelQuestion.Text = "Ищете ли вы интерактивное шоу?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Да");
            comboBoxOptions.Items.Add("Нет");
            buttonConfirm.Click -= OnComedySelected;
            buttonConfirm.Click += new EventHandler(OnSatiricalComedySelected);
        }

        private void OnSatiricalComedySelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedSatirical = comboBoxOptions.SelectedItem.ToString();

            if (selectedSatirical == "Да")
            {
                labelRecommendation.Text = "Посетите интерактивное шоу 'Игра'.";
            }
            else
            {
                labelRecommendation.Text = "Посмотрите фильм 'Бойцовский клуб'.";
            }
        }

        private void ShowInteractiveShowSelection()
        {
            labelQuestion.Text = "Какой тип интерактивного шоу вас интересует?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Комедия с участием зрителей");
            comboBoxOptions.Items.Add("Импровизация");
            buttonConfirm.Click -= OnSatiricalComedySelected;
            buttonConfirm.Click += new EventHandler(OnInteractiveShowSelected);
        }

        private void OnInteractiveShowSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedInteractiveShow = comboBoxOptions.SelectedItem.ToString();

            if (selectedInteractiveShow == "Комедия с участием зрителей")
            {
                labelRecommendation.Text = "Рекомендуем 'Смешанные чувства' — комедия с активным участием зрителей!";
            }
            else
            {
                labelRecommendation.Text = "Попробуйте 'Импровизация 101' — веселое импровизационное шоу!";
            }
        }

        private void ShowTraditionalSatireSelection()
        {
            labelQuestion.Text = "Какой вид традиционной сатиры вас интересует?";
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Items.Add("Сатирическая пьеса");
            comboBoxOptions.Items.Add("Комедийный фильм");
            buttonConfirm.Click -= OnSatiricalComedySelected;
            buttonConfirm.Click += new EventHandler(OnTraditionalSatireSelected);
        }

        private void OnTraditionalSatireSelected(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант.");
                return;
            }

            string selectedTraditionalSatire = comboBoxOptions.SelectedItem.ToString();

            if (selectedTraditionalSatire == "Сатирическая пьеса")
            {
                labelRecommendation.Text = "Рекомендуем 'Сатирические заметки' — отличная пьеса!";
            }
            else
            {
                labelRecommendation.Text = "Посмотрите 'Сатирическая комедия о жизни' — классика жанра!";
            }
        }

        private void button_Back_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Close(); // Закрываем текущую форму
        }
    }
}
