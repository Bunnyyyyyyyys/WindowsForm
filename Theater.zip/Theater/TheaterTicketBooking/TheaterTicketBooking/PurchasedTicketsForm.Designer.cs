﻿using System;

namespace TheaterTicketBooking
{
    partial class PurchasedTicketsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.listBoxPurchasedTickets = new System.Windows.Forms.ListBox();
            this.buttonClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxPurchasedTickets
            // 
            this.listBoxPurchasedTickets.FormattingEnabled = true;
            this.listBoxPurchasedTickets.Location = new System.Drawing.Point(12, 12);
            this.listBoxPurchasedTickets.Name = "listBoxPurchasedTickets";
            this.listBoxPurchasedTickets.Size = new System.Drawing.Size(363, 199);
            this.listBoxPurchasedTickets.TabIndex = 0;
            // 
            // buttonClose
            // 
            this.buttonClose.Location = new System.Drawing.Point(300, 217);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 23);
            this.buttonClose.TabIndex = 1;
            this.buttonClose.Text = "Закрыть";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // PurchasedTicketsForm
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(387, 261);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.listBoxPurchasedTickets);
            this.Name = "PurchasedTicketsForm";
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.ListBox listBoxPurchasedTickets;
        private System.Windows.Forms.Button buttonClose;
    }
}


