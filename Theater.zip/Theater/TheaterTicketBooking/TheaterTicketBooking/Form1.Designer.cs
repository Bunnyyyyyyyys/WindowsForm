﻿namespace TicketBookingApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.comboBoxShows = new System.Windows.Forms.ComboBox();
            this.comboBoxSeatType = new System.Windows.Forms.ComboBox();
            this.numericUpDownTickets = new System.Windows.Forms.NumericUpDown();
            this.buttonPurchase = new System.Windows.Forms.Button();
            this.labelShow = new System.Windows.Forms.Label();
            this.labelSeatType = new System.Windows.Forms.Label();
            this.labelTickets = new System.Windows.Forms.Label();
            this.buttonViewPurchases = new System.Windows.Forms.Button();
            this.labelTicketPrice = new System.Windows.Forms.Label();
            this.labelShowTime = new System.Windows.Forms.Label();
            this.labelDuration = new System.Windows.Forms.Label();
            this.labelGenre = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTickets)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxShows
            // 
            this.comboBoxShows.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxShows.FormattingEnabled = true;
            this.comboBoxShows.Location = new System.Drawing.Point(30, 30);
            this.comboBoxShows.Name = "comboBoxShows";
            this.comboBoxShows.Size = new System.Drawing.Size(200, 21);
            this.comboBoxShows.TabIndex = 0;
            this.comboBoxShows.SelectedIndexChanged += new System.EventHandler(this.comboBoxShows_SelectedIndexChanged);
            // 
            // comboBoxSeatType
            // 
            this.comboBoxSeatType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSeatType.FormattingEnabled = true;
            this.comboBoxSeatType.Location = new System.Drawing.Point(30, 80);
            this.comboBoxSeatType.Name = "comboBoxSeatType";
            this.comboBoxSeatType.Size = new System.Drawing.Size(200, 21);
            this.comboBoxSeatType.TabIndex = 1;
            this.comboBoxSeatType.SelectedIndexChanged += new System.EventHandler(this.comboBoxSeatType_SelectedIndexChanged_1);
            // 
            // numericUpDownTickets
            // 
            this.numericUpDownTickets.Location = new System.Drawing.Point(33, 178);
            this.numericUpDownTickets.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownTickets.Name = "numericUpDownTickets";
            this.numericUpDownTickets.Size = new System.Drawing.Size(200, 20);
            this.numericUpDownTickets.TabIndex = 2;
            this.numericUpDownTickets.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // buttonPurchase
            // 
            this.buttonPurchase.Location = new System.Drawing.Point(30, 204);
            this.buttonPurchase.Name = "buttonPurchase";
            this.buttonPurchase.Size = new System.Drawing.Size(200, 23);
            this.buttonPurchase.TabIndex = 3;
            this.buttonPurchase.Text = "Купить билет";
            this.buttonPurchase.UseVisualStyleBackColor = true;
            this.buttonPurchase.Click += new System.EventHandler(this.buttonPurchase_Click);
            // 
            // labelShow
            // 
            this.labelShow.AutoSize = true;
            this.labelShow.Location = new System.Drawing.Point(30, 15);
            this.labelShow.Name = "labelShow";
            this.labelShow.Size = new System.Drawing.Size(116, 13);
            this.labelShow.TabIndex = 4;
            this.labelShow.Text = "Выберите спектакль:";
            // 
            // labelSeatType
            // 
            this.labelSeatType.AutoSize = true;
            this.labelSeatType.Location = new System.Drawing.Point(30, 65);
            this.labelSeatType.Name = "labelSeatType";
            this.labelSeatType.Size = new System.Drawing.Size(63, 13);
            this.labelSeatType.TabIndex = 5;
            this.labelSeatType.Text = "Тип места:";
            // 
            // labelTickets
            // 
            this.labelTickets.AutoSize = true;
            this.labelTickets.Location = new System.Drawing.Point(30, 162);
            this.labelTickets.Name = "labelTickets";
            this.labelTickets.Size = new System.Drawing.Size(113, 13);
            this.labelTickets.TabIndex = 6;
            this.labelTickets.Text = "Количество билетов:";
            this.labelTickets.Click += new System.EventHandler(this.labelTickets_Click);
            // 
            // buttonViewPurchases
            // 
            this.buttonViewPurchases.Location = new System.Drawing.Point(30, 233);
            this.buttonViewPurchases.Name = "buttonViewPurchases";
            this.buttonViewPurchases.Size = new System.Drawing.Size(200, 23);
            this.buttonViewPurchases.TabIndex = 7;
            this.buttonViewPurchases.Text = "История покупок";
            this.buttonViewPurchases.UseVisualStyleBackColor = true;
            this.buttonViewPurchases.Click += new System.EventHandler(this.buttonViewPurchases_Click);
            // 
            // labelTicketPrice
            // 
            this.labelTicketPrice.AutoSize = true;
            this.labelTicketPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTicketPrice.Location = new System.Drawing.Point(259, 126);
            this.labelTicketPrice.Name = "labelTicketPrice";
            this.labelTicketPrice.Size = new System.Drawing.Size(95, 16);
            this.labelTicketPrice.TabIndex = 6;
            this.labelTicketPrice.Text = "Цена: 0 руб.";
            // 
            // labelShowTime
            // 
            this.labelShowTime.AutoSize = true;
            this.labelShowTime.Location = new System.Drawing.Point(272, 52);
            this.labelShowTime.Name = "labelShowTime";
            this.labelShowTime.Size = new System.Drawing.Size(35, 13);
            this.labelShowTime.TabIndex = 8;
            this.labelShowTime.Text = "label1";
            // 
            // labelDuration
            // 
            this.labelDuration.AutoSize = true;
            this.labelDuration.Location = new System.Drawing.Point(272, 65);
            this.labelDuration.Name = "labelDuration";
            this.labelDuration.Size = new System.Drawing.Size(35, 13);
            this.labelDuration.TabIndex = 9;
            this.labelDuration.Text = "label2";
            // 
            // labelGenre
            // 
            this.labelGenre.AutoSize = true;
            this.labelGenre.Location = new System.Drawing.Point(272, 78);
            this.labelGenre.Name = "labelGenre";
            this.labelGenre.Size = new System.Drawing.Size(35, 13);
            this.labelGenre.TabIndex = 10;
            this.labelGenre.Text = "label3";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(249, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "Информация о спектакле";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(252, 232);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Рекомендации";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(445, 284);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelGenre);
            this.Controls.Add(this.labelDuration);
            this.Controls.Add(this.labelShowTime);
            this.Controls.Add(this.labelTicketPrice);
            this.Controls.Add(this.buttonViewPurchases);
            this.Controls.Add(this.labelTickets);
            this.Controls.Add(this.labelSeatType);
            this.Controls.Add(this.labelShow);
            this.Controls.Add(this.buttonPurchase);
            this.Controls.Add(this.numericUpDownTickets);
            this.Controls.Add(this.comboBoxSeatType);
            this.Controls.Add(this.comboBoxShows);
            this.Name = "MainForm";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTickets)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.ComboBox comboBoxShows;
        private System.Windows.Forms.ComboBox comboBoxSeatType;
        private System.Windows.Forms.NumericUpDown numericUpDownTickets;
        private System.Windows.Forms.Button buttonPurchase;
        private System.Windows.Forms.Label labelShow;
        private System.Windows.Forms.Label labelSeatType;
        private System.Windows.Forms.Label labelTickets;
        private System.Windows.Forms.Button buttonViewPurchases;
        private System.Windows.Forms.Label labelTicketPrice;
        private System.Windows.Forms.Label labelShowTime;
        private System.Windows.Forms.Label labelDuration;
        private System.Windows.Forms.Label labelGenre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}


