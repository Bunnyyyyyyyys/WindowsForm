﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheaterTicketBooking
{
    public partial class PurchasedTicketsForm : Form
    {
        public PurchasedTicketsForm(string[] purchasedTickets)
        {
            InitializeComponent();
            foreach (var ticket in purchasedTickets)
            {
                listBoxPurchasedTickets.Items.Add(ticket);
            }
        }

        private void buttonClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

    }
}
